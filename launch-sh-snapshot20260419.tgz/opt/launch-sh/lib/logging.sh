
SYSLOG_LOGPREFIX="launch-sh"
SYSLOG_FACILITY="local4"

declare -A LOG_LEVELS=( [NOTSET]=0 [DEBUG]=10 [INFO]=20 [WARNING]=30 [ERROR]=40 [CRITICAL]=50 )

LOG_LEVEL=INFO

# log_msg:  Display log/status message to interactive user (if appropriate); copy message to syslog local4
# Usage:
#
# log_msg <LEVEL> <printf fmt> [<printf arg> [<printf arg>]]
#
# See:  "man logger" for log levels (should match Python/Posix)
#       "man -s 1 printf" for printf fmt/arg 
function log_msg() {
    local args=( "${@}" )
    local msg_log_level=${args[0]^^}    #bash-ism: upper case
    local numeric_log_level=${LOG_LEVELS[${msg_log_level}]:-0}

    local printf_args=( "${args[@]:1}" )

    local syslog_line_prefix=$(echo -n user="$USER" \
                    cfg="${K8S_CONFIG_SOURCE:-unknown-config-source}" \
                    pod="${K8S_POD_NAME:-unknown-pod}" "--" )

    local console_line_prefix="$(date) ${msg_log_level}"

    local msg=$(printf "${printf_args[@]}")

    # Output prefix+msg to syslog
    echo "$msg" | sed -e "s#^#${syslog_line_prefix} #" | \
        logger -t 'launch-sh' -p ${SYSLOG_FACILITY}"."${msg_log_level}

    # And to console
    # FIXME: should choose whether to print based on calculated log severity
    # (and "-q" command line option should instead set verbosity)
    # Once done, we can transition away from FD #3 and just print to stderr
    if (( ${numeric_log_level} >= ${LOG_LEVELS[ERROR]} )); then
        echo "$msg" | sed -e "s#^#${console_line_prefix} #" >&2
    elif (( ${numeric_log_level} >= ${LOG_LEVELS[${LOG_LEVEL}]} )); then
        echo "$msg" | sed -e "s#^#${console_line_prefix} #" >&3
    fi
}


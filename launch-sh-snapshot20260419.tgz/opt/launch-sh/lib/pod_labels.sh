#!/bin/bash

function join () {
  local IFS="$1"
  shift
  echo "$*"
}

###########
# Apply custom labels to the pod (e.g. for service matching)
function setup_custom_labels() {

    if (( ${#CUSTOM_LABELS[@]} )); then
        local x k v
        for x in ${CUSTOM_LABELS[@]}; do
            IFS="=" read k v <<<"$x"

            # See https://stackoverflow.com/questions/35841309/construct-json-with-a-variable-key-using-jq 
            # re using variable as key
            apply_jq --arg k "$k" --arg v "$v" \
                '.metadata?.labels? += { "\($k)": "\($v)" }'
        done
    fi

}


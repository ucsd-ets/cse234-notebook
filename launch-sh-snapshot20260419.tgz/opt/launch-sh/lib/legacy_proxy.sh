
function setup_webproxy_ucsd() {
    set_c_env       "${CN}"   "http_proxy"      "http://web.ucsd.edu:3128"
    set_c_env       "${CN}"   "https_proxy"     "http://web.ucsd.edu:3128"
}

function findports() {
    local PORTS_IN_USE p HOST PORT     TGT N_PORTS_REMAIN 

    declare -A PORTS_IN_USE
    for p in $( netstat -a -t -n | grep LISTEN | while read -a INP; do
        IFS=\: read HOST PORT <<<"${INP[3]}"
        if [ "${INP[5]}" = "LISTEN" ]; then
            echo $PORT
        fi
    done ); do
        PORTS_IN_USE[$p]=1
    done

    TGT=""
    N_PORTS_REMAIN=${1:-"1"}
    for ((i= $(( 8000 + ($K8S_UID % 12500) )) ;i<=25000;i++)); do
        if [[ ! ${PORTS_IN_USE[$i]} ]] ; then
            TGT="${TGT} $i"
                        N_PORTS_REMAIN=$((N_PORTS_REMAIN-1))
        fi
                if [ $N_PORTS_REMAIN -eq 0 ]; then
                        break;
                fi
    done

    echo $TGT
}

# Must be declared outside function to be treated as global!
declare -A SOCAT_PORT_MAP
declare -A IDENTITY_PORT_MAP
function setup_legacy_proxy() {

    local -A ports

    for p in ${PROXY_PORT//:/ }; do
        ports[$p]=1
    done

    [ "$K8S_ENABLE_JUPYTER" = "YES" ] && ports[${JUPYTER_PORT}]=1
    [ "$K8S_ENABLE_CODESERVER" = "YES" ] && ports[${CODE_SERVER_PORT}]=1

    local port_cnt=${#ports[@]}

    # tests if IDENTITY_PROXY_PORTS is an integer > 0
    # if so, increment number of proxy ports required
    (( IDENTITY_PROXY_PORTS )) && port_cnt=$(( port_cnt + IDENTITY_PROXY_PORTS ))

    if (( port_cnt == 0 )); then
        return
    fi

    mapped_ports=( $(findports $port_cnt ) )

    # tracks assigned ports across following two loops
    n=0

    for p in ${!ports[@]}; do
        SOCAT_PORT_MAP[$p]=${mapped_ports[$n]}
        n=$(( $n + 1 ))
    done

    local q
    for ((q=0; q < IDENTITY_PROXY_PORTS; q++)); do
        SOCAT_PORT_MAP[${mapped_ports[$n]}]=${mapped_ports[$n]}
        IDENTITY_PORT_MAP[${mapped_ports[$n]}]=$(( q + 1 ))
        n=$(( $n + 1 ))
    done

    PROXY_HOSTNAME=`hostname`
    PROXY_IP=$(host -t a `hostname` | sed -e 's#^.*has address ##')

    LAUNCH_HOOKS+=( "launch_legacy_proxy" )
    LAUNCH_HOOKS+=( "hook_legacyproxy_displayurl" )
    CLEANUP_HOOKS+=( "cleanup_legacy_proxy" )
}

function hook_legacyproxy_displayurl() {
    local ext_port dest_port

    for dest_port in ${!SOCAT_PORT_MAP[@]}; do
        ext_port=${SOCAT_PORT_MAP[${dest_port}]}
        if [ "${IDENTITY_PORT_MAP[${dest_port}]}" ]; then
            echo "Identity port map ${IDENTITY_PORT_MAP[${dest_port}]}: Container port ${dest_port} mapped to ${PROXY_HOSTNAME}:${ext_port}"
        else 
            echo "Container port ${dest_port} mapped to http://${PROXY_HOSTNAME}:${ext_port}/"
        fi
    done
}

function run_kubectl_port_forward() {
    local podname=$1
    local localport=$2
    local podport=$3

    local ppid=$PPID

    trap INT 2>/dev/null; trap EXIT 2>/dev/null
    # Redirect all output to /dev/null so as to not disturb parent process shell session
    exec 1>/dev/null; exec 2>/dev/null; exec 3>/dev/null
    while : ; do
        log_msg DEBUG "Starting kubectl port-forward; our PID=$$; PPID=${ppid}"

        nohup kubectl port-forward ${K8S_POD_NAME} --address ${PROXY_IP} ${socat_port}:${dest_port} < /dev/null > /dev/null 2>&1 &
        #^^ We run the command above in the background so that the termination signal from our parent
        # can be acted upon.  ("wait" below waits for either an exiting child, or a signal)

        KPF_PID=$!

        trap "kill -QUIT $KPF_PID; exit" USR1
        trap "kill -QUIT $KPF_PID; exit" HUP
        trap "kill -QUIT $KPF_PID; exit" INT
        trap "kill -QUIT $KPF_PID; exit" TERM
        trap "kill -QUIT $KPF_PID; exit" EXIT
        #Ideally, parent will send us a USR1 signal when it's time to wrap up;
        #   when that happens, terminate most recent port-forward process, then exit ourselves
        #Trap other signals in case parent is killed before it's able to send signal

        wait $KPF_PID

        # Probe our parent process - if it's died, wind up our process
        if ! kill -0 ${ppid}; then
            kill -QUIT $KPF_PID
            exit
        fi

        log_msg INFO "Restarting kubectl port-forward after exit code: $?"

        sleep 10
   done 
}

function launch_legacy_proxy() {
    KUBE_FWD_PID=""
    for dest_port in ${!SOCAT_PORT_MAP[@]}; do
        socat_port=${SOCAT_PORT_MAP[$dest_port]}
        if [[ ! $socat_port ]]; then
            echo $(date) "Could not allocate port forwarding port - contact ITS/ETS for support"
            exit 1
        fi

        run_kubectl_port_forward ${K8S_POD_NAME} ${socat_port} ${dest_port} &
        KUBE_FWD_PID="${KUBE_FWD_PID} $!"
    done
}

function monitor_legacy_proxy() {
    echo "Monitor legacy proxy"
}

function cleanup_legacy_proxy() {
    for test_pid in ${KUBE_FWD_PID}; do
        kill -USR1 ${test_pid} 2>/dev/null
    done
}


#!/bin/bash

# Ensure our checked out copy is world readable/executable,
# but that our git dir is kept private

find . \( -name '.git' -prune \) -o -print0 | xargs -0 chmod og+rX
chmod 0700 .git

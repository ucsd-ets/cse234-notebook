#!/bin/bash

#################
# Set up UID, Group ID, etc.
function setup_security_context() {
    apply_jq --arg uid "$K8S_UID" '.spec.securityContext += { runAsUser: ($uid |tonumber) }'

    setup_awsed_groups
}


function setup_legacy_security_context() {
    if [ "$K8S_EXTRA_SECURITY_CONTEXT" ]; then
        local d=( $(echo "$K8S_EXTRA_SECURITY_CONTEXT" | base64 -d) )
        if [ "${d[0]}" = "runAsGroup:" ]; then
            local gr=${d[1]}
            apply_jq --arg gid "$gr" '.spec.securityContext += { runAsGroup: ($gid |tonumber) }'
        fi
    fi

}

function setup_awsed_groups() {
    local k8s_tok=$(kubectl config view --minify=true --flatten -o jsonpath='{.users[0].user.token}')
    local -a gr grn grjson defgr
    local curl_script g n

    #FIXME - what if k8s_tok lookup fails, or the curl below fails?

    IFS='' read -d '' -r curl_script << EOM
silent
header = "Authorization: AWSEd api_key=${k8s_tok}"
url = ${AWSED_ENDPOINT}/teams?username=${K8S_USERNAME}
EOM

    grjson=$(curl -s -K - <<<"${curl_script}" 2>/dev/null)
    gr=( $(echo "$grjson" | jq -r '.teams[] | [.gid] | @tsv' 2>/dev/null) )
    grn=( $(echo "$grjson" | jq -r '.teams[] | [.uniqueName] | @tsv' 2>/dev/null) )

    # If any results return, set a runAsGroup - otherwise default to whatever PSP/OPA specifies
    if (( ${#gr[@]} )); then
        if [ "${K8S_PRIMARY_GROUP}" ]; then
            defgr=$( echo "$grjson" | jq -r --arg grname "${K8S_PRIMARY_GROUP}" -r '.teams[] | [ select(.uniqueName == $grname) ] | .[0].gid? // empty')
            if [ -z "$defgr" ]; then
                echo "$0: Error- could not find requested group '${K8S_PRIMARY_GROUP}'." 1>&2
                echo -n "Known group names: " 1>&2
                echo "${grn[@]}" 1>&2
                exit 1
            fi
        else
            if (( ${#gr[@]} > 1 )); then
                echo $(date) $(printf "Defaulting to primary group ID %s (all: %s); use '$0 -G <groupname> [...]' to change." "${grn[0]}" "${grn[*]}") 1>&3
            fi
            defgr="${gr[0]}"
        fi

        for g in "${gr[@]}"; do
            apply_jq --arg gid "$g" '.spec.securityContext.supplementalGroups? += [ ($gid |tonumber) ]'
        done

        apply_jq --arg gid "${defgr}" '.spec.securityContext += { runAsGroup: ($gid |tonumber) }'

        # FIXME: We should populate an associative array with GRNAME=grid tuples,
        # rather than maintaining two separate arrays "gr" and "grn", and expecting their contents to
        # remain aligned.  NB: the code below empties "grn".
        # Now map group name/gid into Env variables, for consumption by initenv/nsswrapper 
        for g in "${gr[@]}"; do
            # Transform awsed.ucsd.edu group uniqueName to something readable
            n=$(echo "${grn[0]}" | sed -e 's/^rits_*//i' -e 's/group[0-9]*$//')

            set_c_env       "${CN}"   "ETC_GROUP_${n}" "${g}"

            grn=("${grn[@]:1}")
        done

    fi
}

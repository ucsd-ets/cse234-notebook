#!/bin/bash

###########
# Apply tolerations to the pod (e.g. for high-end GPU)
function setup_tolerations() {

    if (( ${#TOLERATIONS[@]} )); then
        local x k v
        for x in ${TOLERATIONS[@]}; do
            IFS="=" read k v <<<"$x"

            if [ "$v" ]; then
                apply_jq --arg k "$k" --arg v "$v" \
                    '.spec?.tolerations? += [ { "key": "\($k)", "operator": "Equal", "value": "\($v)", "effect": "NoSchedule" } ]'
            else
                apply_jq --arg k "$k" \
                    '.spec?.tolerations? += [ { "key": "\($k)", "operator": "Exists", "effect": "NoSchedule" } ]'
            fi

        done
    fi

}


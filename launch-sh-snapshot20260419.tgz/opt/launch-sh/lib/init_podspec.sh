#!/bin/bash


###########
# Set up our pod template & basic pod metadata (name)
function setup_initial_podspec() {
    JSON=$(cat $K8S_TEMPLATE)

    # We will arbitrarily target the first container listed
    # in the template, unless override is provided
    CONTAINERS=( $(list_c) )
    CN=${K8S_TARGET_CONTAINER:-CONTAINERS[0]}

    # The first hook to modify the container command args will set this; further attempts to modify will generate an error
    CN_CMD_MODIFIED=NO

    K8S_POD_NAME=${K8S_POD_NAME:-${K8S_USERNAME}-$$}

    K8S_HOME=/home/${K8S_USERNAME}
    K8S_NAMESPACE=${K8S_NAMESPACE:-$K8S_USERNAME}

    apply_jq \
        --arg namespace "$K8S_NAMESPACE" \
        --arg podname "$K8S_POD_NAME" \
            '.metadata? += { name: $podname, namespace: $namespace }'

    # This should be optional - not needed for legacy proxy setup
    apply_jq \
            '.metadata?.labels? += { svcreg: "true" }'

    apply_jq --arg app "$launched_by"        '.metadata.labels += { "app": ($app) }'

    set_c_env       "${CN}"   "USER"      "${K8S_USERNAME}"
    set_c_env       "${CN}"   "LOGNAME"   "${K8S_USERNAME}"
    set_c_env       "${CN}"   "HOME"      "${K8S_HOME}"

    set_c_env       "${CN}"   "XDG_CACHE_HOME"    "/tmp/xdg-cache"
    set_c_env       "${CN}"   "TERM"              "xterm"
    set_c_env       "${CN}"   "TZ"                "PST8PDT"
    set_c_env       "${CN}"   "SHELL"             "/bin/bash"

    set_c_env       "${CN}"   "DOCKER_IMAGE"      "${K8S_DOCKER_IMAGE}"
    apply_c         "${CN}"   '.image = $img' --arg img "${K8S_DOCKER_IMAGE}"

    apply_c         "${CN}"   '.imagePullPolicy = $ipp' --arg ipp "${K8S_IMAGE_PULL_POLICY}"

    # follow up on -E flag
    if [ "${K8S_PULL_SECRET}" != "" ]; then
      apply_jq        --arg ips "${K8S_PULL_SECRET}" '.spec.imagePullSecrets += [{ "name": ($ips) }] '
    fi

    apply_c         "${CN}"   '.workingDir = $d' --arg d "${K8S_HOME}"
    set_c_volumeMount "${CN}" "home" "${K8S_HOME}"
}

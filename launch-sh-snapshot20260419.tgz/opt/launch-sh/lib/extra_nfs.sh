
# Support arbitrary NFS mounts (
#
function setup_extra_nfs_mount() {
    local mntlist mntinfo a d
    IFS=, read -a mntlist <<<"$K8S_EXTRA_NFS_MOUNT"

    for a in "${mntlist[@]}"; do
        # Omit blank entries to permit blind appending of additional entries # # K8S_EXTRA_NFS_MOUNT="${K8S_EXTRA_NFS_MOUNT};${new-mntblock}"
        [[ "$a" == "" ]] && continue

        IFS=: read -a mntinfo <<<"$a"

        if (( ${#mntinfo[@]} != 3 )) || [[ ! ${mntinfo[0]} =~ ^/ ]] || [[ ! ${mntinfo[1]} =~ ^[-0-9a-z.]+$ ]] || [[ ! ${mntinfo[2]} =~ ^/ ]]; then
            echo "$0: malformed K8S_EXTRA_NFS_MOUNT; expected: /mountpoint:server_fqdn:/server_path[,/mountpoint2:server2_fqdn:/server2_path,..." 1>&2
            exit 1
        fi

        d="extramount-"`basename ${mntinfo[0]}`

        apply_jq '.spec.volumes += [ { name: "'"${d}"'", nfs: { path: "'${mntinfo[2]}'", server: "'${mntinfo[1]}'" } } ]'
        set_c_volumeMount "${CN}" "${d}" "${mntinfo[0]}"
    done
}

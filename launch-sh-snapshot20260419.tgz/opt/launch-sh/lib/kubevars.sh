#!/bin/bash

K8S_USERNAME=${K8S_USERNAME:-$USER}
K8S_UID=`id -u $K8S_USERNAME`
KUBECFG_DIR="/home/linux/dsmlp/${K8S_UID:(-2)}/${K8S_UID:(-3)}/${K8S_USERNAME}"
PROTO_KUBECONFIG=${KUBECFG_DIR}/.kube/config
export KUBECONFIG=${KUBECONFIG:-$PROTO_KUBECONFIG}
AWSED_ENDPOINT="https://awsed.ucsd.edu/api"
# If called as a standalone script (as opposed to being sourced within another script),
# output the kubeconfig location
[ "$0" = "$BASH_SOURCE" ] && echo $KUBECONFIG

#!/bin/bash

# 'launch.sh' callers may pass environment variables through to the pod
# by prefixing those variables with $(K8S_EXPORT_ENV_PREFIX) 
#
# e.g.
#
# export K8S_EXPORT_ENV_PREFIX=MYPOD
# export MYPOD_APP_DIR=/var/something/
#
# would add "APP_DIR=/var/something/" to the pod environment

################
function setup_extra_env_vars() {
    [ -z "${K8S_EXPORT_ENV_PREFIX}" ] && return

    # Compile list of environment variable names matching the defined prefix
    local expvars=( $(declare -x | while read a; do [[ $a =~ ^declare....(${K8S_EXPORT_ENV_PREFIX}[^=]+)= ]] && echo ${BASH_REMATCH[1]}; done) )

    local p
    for p in "${expvars[@]}"; do
        local k=${p/#${K8S_EXPORT_ENV_PREFIX}/};
        local v=${!p}

        set_c_env       "${CN}"   "${k}" "${v}"
    done
}


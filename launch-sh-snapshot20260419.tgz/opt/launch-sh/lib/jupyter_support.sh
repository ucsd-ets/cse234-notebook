#!/bin/bash

JUPYTER_NOTE=
function hook_jupyter_displayurl() {
    echo "You may access your Jupyter notebook at:  ${JUPYTER_URL}"
    if [ "$JUPYTER_NOTE" ]; then
      echo "$JUPYTER_NOTE"
    fi
}

################
# Set up Jupyter
JUPYTER_PORT=8888
function setup_jupyter() {
    if [ "$CN_CMD_MODIFIED" != "NO" ]; then
        echo "$0: only one container command modification permitted; cur=jupyter; previous=$CN_CMD_MODIFIED"; exit 1;
    fi
    CN_CMD_MODIFIED="jupyter"

    local tmp_tok=($(dd if=/dev/urandom bs=512 count=1 status=none | sha256sum))
    local jup_token=${tmp_tok[0]}

    local jup_base=/user/${K8S_USERNAME}

    apply_c_stdin         "${CN}"              <<EOM
        .command = [ .command[], 
        "/usr/local/bin/start-notebook.sh",
        "--ip=0.0.0.0", 
        "--NotebookApp.base_url=${jup_base}",
        "--NotebookApp.notebook_dir=${K8S_HOME}",
        "--NotebookApp.token=${jup_token}"
        ]
EOM

    if [ "$LEGACY_PROXY" = "YES" ]; then
        jup_port=${SOCAT_PORT_MAP[${JUPYTER_PORT}]:-}
        if [ \! "$jup_port" ]; then
            echo "Error: could not allocate Legacy jupyter proxy port; contact ITS/ETS" 1>&2
            exit 1
        fi

        if [ "$JUPYTER_CLIENT_PORT" ]; then
            JUPYTER_URL="http://127.0.0.1:${JUPYTER_CLIENT_PORT}${jup_base}/?token=${jup_token}"
           JUPYTER_NOTE="** Assuming SSH port-forwarding is active (ex:  ssh ${K8S_USERNAME}@${PROXY_HOSTNAME} -L ${JUPYTER_CLIENT_PORT}:${PROXY_IP}:${jup_port} ); if needed, start a second SSH session."
       else
            JUPYTER_URL="http://${PROXY_HOSTNAME}:${jup_port}${jup_base}/?token=${jup_token}"
       fi

    else
        JUPYTER_URL="https://userproxy.dsmlp.ucsd.edu${jup_base}/?token=${jup_token}"
    fi

    set_c_env       "${CN}"   "JUPYTER_TOKEN"      "${jup_token}"
    set_c_env       "${CN}"   "JUPYTER_URL"        "${JUPYTER_URL}"

    set_c_env       "${CN}"   "NB_USER"        "${K8S_USERNAME}"
    set_c_env       "${CN}"   "NB_UID"         "${K8S_UID}"

    # Push hook call to display the URL
    LAUNCH_HOOKS+=( hook_jupyter_displayurl )
}


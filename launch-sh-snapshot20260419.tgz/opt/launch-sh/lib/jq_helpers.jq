
# https://stackoverflow.com/a/41963541
# 0-based index of item in input array such that f is truthy, else null
def which(f):
  label $out
  | foreach .[] as $x (-1; .+1; if ($x|f) then ., break $out else empty end)
  // null ;

def fc($cn; fn):
    # Pipe .containers through the filter ; 
    .spec.containers[ (.spec.containers|which(.name=$cn)) ] |= fn
        ;

def rc($cn; fn):
    # Pipe .containers through the filter ; 
    .spec.containers[ (.spec.containers|which(.name=$cn)) ] | fn
        ;


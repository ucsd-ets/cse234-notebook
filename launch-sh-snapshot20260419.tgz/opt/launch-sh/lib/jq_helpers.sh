#!/bin/bash

BASEDIR=${BASEDIR:-$(dirname $(cd $(dirname ${BASH_SOURCE[0]}) && pwd))}
LIBDIR=${LIBDIR:-${BASEDIR}/lib}

function apply_jq() {
    [ "$DEBUG_FC_SH" ] && echo "apply_jq():" "$@" 1>&2
    JSON=$( jq -L${LIBDIR} "$@" <<< "$JSON")
}

function fetch_jq() {
    [ "$DEBUG_FC_SH" ] && echo "fetch_jq():" "$@" 1>&2
    jq -L${LIBDIR} "$@" <<< "$JSON"
}

function apply_jq_stdin() {
    local jqdata

    IFS='' read -d '' -r jqdata
    apply_jq "$jqdata" "${@:1}"
}

function list_c() {
    fetch_jq ".spec.containers[]? | .name? | @text" -r 
}

function apply_c() {
    local cn=$1
    local f=$2

    apply_jq --arg cn "$cn" \
        'include "jq_helpers"; . | fc($cn; '"${f}"')' \
        "${@:3}" 
}

function fetch_c() {
    local cn=$1
    local f=$2

    fetch_jq --arg cn "$cn" \
        'include "jq_helpers"; . | rc($cn; '"${f}"')' \
        "${@:3}" 
}

function apply_c_stdin() {
    local cn=$1
    local jqdata

    IFS='' read -d '' -r jqdata
    apply_c "$cn" "$jqdata" "${@:2}"
}

# Set environment variable in specified container
function set_c_env() {
    local cn=$1
    local k=$2
    local v=$3

    apply_c "$cn" '.env = [ .env[]? | select(.name != $k ) ] | .env += [ { name: $k, value: $v } ]' \
        --arg k "$k" --arg v "$v"
}

# Get environment variable in specified container
function fetch_c_env() {
    local cn=$1
    local k=$2

    fetch_c "$cn" '.env[]? | select(.name == $k) | .value' \
        -r --arg k "$k"
}

# Set environment variable in specified container
function set_c_volumeMount() {
    local cn=$1
    local n=$2
    local p=$3

    apply_c "$cn" '.volumeMounts = [ .volumeMounts[]? | select(.name != $n ) ] | .volumeMounts += [ { name: $n, mountPath: $p } ]' \
        --arg p "$p" --arg n "$n"
}

function set_c_resources() {
    local cn=$1
    local ka=$2
    local kb=$3
    local v=$4

    apply_jq --arg cn "$cn" --arg ka "$ka" --arg kb "$kb" --arg v "$v" \
        'include "jq_helpers"; . | fc($cn; .resources[$ka][$kb] = $v)'
}

function prepend_c_path() {
    local cn=$1
    local k=$2
    local v=$3
    local semi

    local cp=$(fetch_c_env "$cn" "$k")
    if [ "$cp" ]; then
        semi=":"
    fi

    set_c_env "$cn" "$k" "${v}${semi}${cp}"
}


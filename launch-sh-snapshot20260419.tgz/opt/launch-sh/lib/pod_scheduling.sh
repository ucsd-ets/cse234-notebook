#!/bin/bash

function setup_pod_scheduling() {
    if [ "$K8S_NODENUM" ]; then
        if [[ "$K8S_NODENUM" =~ ^[[:digit:]]+$ ]]; then
            printf -v K8S_NODENUM "its-dsmlp-n%02d.ucsd.edu" $K8S_NODENUM
        fi

        apply_jq '.spec.nodeSelector = { "kubernetes.io/hostname": $node }' \
            --arg node "${K8S_NODENUM}"
    fi

    local ads
    if [ "${K8S_PRIORITY_CLASS_NAME}" = "low" ]; then
        ads=${K8S_TIMEOUT_SECONDS:-$(( 3600 * 48 ))}
    else
        ads=${K8S_TIMEOUT_SECONDS:-$(( 3600 * 6 ))}
        if (( $ads > (3600 * 12) )) && [ -z "${K8S_BYPASS_TIMEOUT_LIMIT}" ]; then
                echo "K8S_TIMEOUT_SECONDS may not exceed 12 hours.  Please contact ITS/ETS for assistance." >&2
                exit 1
        fi
    fi

    apply_jq '.spec += { restartPolicy: "Never", priorityClassName: $pc, activeDeadlineSeconds: ( $ads | tonumber ) }' \
            --arg ads "$ads"  \
            --arg pc "$K8S_PRIORITY_CLASS_NAME" 

}

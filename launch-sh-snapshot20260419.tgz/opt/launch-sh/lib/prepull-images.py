import sys
import subprocess
import time
import pwd
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse
import math

# Global variables
GLOBAL_TIMEOUT = 60  # Default timeout in seconds
DEFAULT_NODES = [
    "its-dsmlp-n01.ucsd.edu",
    "its-dsmlp-n02.ucsd.edu",
    "its-dsmlp-n03.ucsd.edu",
    "its-dsmlp-n04.ucsd.edu",
    "its-dsmlp-n05.ucsd.edu",
    "its-dsmlp-n06.ucsd.edu",
    "its-dsmlp-n07.ucsd.edu",
    "its-dsmlp-n08.ucsd.edu",
    "its-dsmlp-n11.ucsd.edu",
    "its-dsmlp-n12.ucsd.edu",
    "its-dsmlp-n18.ucsd.edu",
    "its-dsmlp-n19.ucsd.edu",
    "its-dsmlp-n20.ucsd.edu",
    "its-dsmlp-n21.ucsd.edu",
    "its-dsmlp-n22.ucsd.edu",
    "its-dsmlp-n24.ucsd.edu",
    "its-dsmlp-n25.ucsd.edu",
    "its-dsmlp-n26.ucsd.edu",
    "its-dsmlp-n27.ucsd.edu",
    "its-dsmlp-n28.ucsd.edu"
]

def check_user():
    try:
        current_user = pwd.getpwuid(os.getuid()).pw_name
        if current_user != 'testacct333':
            print("This script can only be run by testacct333!")
            sys.exit(1)
    except Exception as e:
        print(f"Could not verify user identity: {e}")
        sys.exit(1)

def delete_pod(node):
    """Delete the pod for a given node"""
    pod_name = f"prepull-{node}"
    try:
        cmd = ['kubectl', 'delete', 'pod', pod_name, "--force", "--grace-period=0"]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode == 0:
            print(f"Initiated cleanup of pod {pod_name}")
        else:
            print(f"Note: Pod {pod_name} may already be terminated or cleaning up: {result.stderr}")
    except Exception as e:
        print(f"Error while deleting pod {pod_name}: {e}")

def get_k8s_nodes():
    try:
        from kubernetes import client, config

        try:
            config.load_kube_config()
        except:
            config.load_incluster_config()

        v1 = client.CoreV1Api()
        nodes = []
        skipped_nodes = []
        not_student_nodes = []
        node_list = v1.list_node()

        for node in node_list.items:
            node_name = node.metadata.name

            # Check if node has the student partition label
            if not (node.metadata.labels and
                   node.metadata.labels.get('dsmlp/partition') == 'student'):
                not_student_nodes.append(node_name)
                if not node.metadata.labels:
                    print(f"Node {node} does not have any labels, ignoring...")
                continue

            # Skip nodes that are unschedulable
            if node.spec.taints:
                for taint in node.spec.taints:
                    if (taint.key == 'node.kubernetes.io/unschedulable' and
                        taint.effect == 'NoSchedule'):
                        skipped_nodes.append(node_name)
                        break

            if node_name not in skipped_nodes:
                nodes.append(node_name)

        if not_student_nodes:
            print(f"Skipped nodes that do not have the student partition: {', '.join(not_student_nodes)}\n")

        if skipped_nodes:
            print(f"Skipped cordoned nodes: {', '.join(skipped_nodes)}\n")

        if not nodes:
            print(f"Nodes unable to be fetched from k8s. Using default node list.")
            return DEFAULT_NODES
        return nodes

    except ImportError:
        print("Kubernetes Python client not installed. Using default node list.")
        return DEFAULT_NODES
    except Exception as e:
        print(f"Failed to get nodes from Kubernetes API: {e}. Using default node list.")
        return DEFAULT_NODES

def run_launch(node, image_name, timeout):
    print(f"Launching on node {node}...")
    cmd = [
        '/opt/launch-sh/bin/launch.sh', '-i', image_name,
        '-c', '1', '-m', '1', '-f', '-P', 'Always', '-N', f'prepull-{node}',
        '-n', node, '--', 'echo', f'Successfully pulled {image_name} on {node}.'
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if result.returncode == 0:
            print(f"Successfully launched on node {node}.\nOutput:\n{result.stdout}")
            return True
        else:
            print(f"Failed to launch on node {node}. Error:\n{result.stderr}")
            delete_pod(node)
            return False
    except subprocess.TimeoutExpired:
        print(f"Timeout occurred after {timeout} seconds on node {node}")
        delete_pod(node)
        return False
    except Exception as e:
        print(f"An error occurred on node {node}: {e}")
        delete_pod(node)
        return False

def get_resource_limits():
    """Get the maximum CPU and memory limits for the current namespace"""
    try:
        from kubernetes import client, config
        from kubernetes.utils import parse_quantity
        
        try:
            config.load_kube_config()
        except:
            config.load_incluster_config()
            
        v1 = client.CoreV1Api()
        current_namespace = pwd.getpwuid(os.getuid()).pw_name
        
        # Get LimitRange for the namespace
        limit_ranges = v1.list_namespaced_limit_range(namespace=current_namespace)
        
        max_cpu = 8  # Default max CPU
        max_memory = 64  # Default max memory in Gi
        
        if limit_ranges.items:
            for limit_range in limit_ranges.items:
                for limit in limit_range.spec.limits:
                    if limit.type == 'Container':
                        if limit.max:
                            if 'cpu' in limit.max:
                                max_cpu = parse_quantity(limit.max['cpu'])
                            if 'memory' in limit.max:
                                # Convert to Gi for easier handling
                                max_memory = parse_quantity(limit.max['memory']) / (1024 * 1024 * 1024)
        
        return max_cpu, max_memory
        
    except ImportError:
        print("Kubernetes Python client not installed. Using default resource limits.")
        return 8, 64  # Default values
    except Exception as e:
        print(f"Failed to get resource limits: {e}. Using default values.")
        return 8, 64  # Default values

def calculate_batch_size(total_nodes, max_cpu, max_memory):
    cpu_limited_batch = math.floor(max_cpu)
    memory_limited_batch = math.floor(max_memory)
    
    # Take the minimum of the two limits and the total number of nodes
    batch_size = min(cpu_limited_batch, memory_limited_batch, total_nodes)
    return max(1, batch_size)  # Ensure at least 1 concurrent pull

def process_nodes_in_batches(nodes, image_name, timeout, batch_size):
    successful_nodes = 0
    failed_nodes = []
    total_batches = math.ceil(len(nodes) / batch_size)
    
    for batch_num in range(total_batches):
        start_idx = batch_num * batch_size
        end_idx = min(start_idx + batch_size, len(nodes))
        current_batch = nodes[start_idx:end_idx]
        
        print(f"\nProcessing batch {batch_num + 1}/{total_batches} ({len(current_batch)} nodes)")
        
        with ThreadPoolExecutor(max_workers=len(current_batch)) as executor:
            futures = {}
            for node in current_batch:
                print(f"Submitting job for node {node}")
                futures[executor.submit(run_launch, node, image_name, timeout)] = node
            
            for future in as_completed(futures):
                node = futures[future]
                try:
                    if future.result():
                        successful_nodes += 1
                    else:
                        failed_nodes.append(node)
                except Exception as e:
                    failed_nodes.append(node)
                    print(f"An error occurred on node {node}: {e}")
                    delete_pod(node)
        
        # Wait between batches if not the last batch
        if batch_num < total_batches - 1:
            print(f"Waiting 5 seconds before processing next batch...")
            time.sleep(5)
    
    return successful_nodes, failed_nodes

def parse_arguments():
    parser = argparse.ArgumentParser(description='Launch containers on DSMLP nodes with timeout')
    parser.add_argument('images', nargs='+', help='One or more image names to pull')
    parser.add_argument('-t', '--timeout', type=int, default=GLOBAL_TIMEOUT,
                      help=f'Timeout in seconds (default: {GLOBAL_TIMEOUT})')
    return parser.parse_args()

def main():
    args = parse_arguments()
    nodes = get_k8s_nodes()
    total_nodes = len(nodes)
    
    print(f"Using nodes: {', '.join(nodes)}")

    # Get resource limits
    max_cpu, max_memory = get_resource_limits()
    print(f"Resource limits: {max_cpu} CPU, {max_memory}Gi Memory")
    
    # Calculate batch size based on resource limits
    batch_size = calculate_batch_size(total_nodes, max_cpu, max_memory)
    print(f"Using batch size of {batch_size} concurrent pulls")

    print(f"Timeout set to {args.timeout} seconds")
    
    for img_index, image_name in enumerate(args.images):
        print(f"\nPrepulling {image_name}...")
        
        successful_nodes, failed_nodes = process_nodes_in_batches(
            nodes, image_name, args.timeout, batch_size
        )
        
        print(f"\n=== Successfully pulled {image_name} on {successful_nodes}/{total_nodes} nodes ===")
        if failed_nodes:
            print(f"= Failed nodes: {', '.join(failed_nodes)} =")
        
        # Only wait if this isn't the last image
        if img_index < len(args.images) - 1:
            print(f"Waiting 5 seconds before processing next image...")
            time.sleep(5)


if __name__ == '__main__':
    main()

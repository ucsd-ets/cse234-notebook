#!/bin/bash

function join () {
  local IFS="$1"
  shift
  echo "$*"
}

###########
# Apply custom annotations to the pod (e.g. for specifying Calico fixed MAC addresses)
function setup_custom_annotations() {

    if (( ${#CUSTOM_ANNOTATIONS[@]} )); then
        local x k v
        for x in ${CUSTOM_ANNOTATIONS[@]}; do
            IFS="=" read k v <<<"$x"

            # See https://stackoverflow.com/questions/35841309/construct-json-with-a-variable-key-using-jq 
            # re using variable as key
            apply_jq --arg k "$k" --arg v "$v" \
                '.metadata?.annotations? += { "\($k)": "\($v)" }'
        done
    fi

}




function setup_nbmessages() {
    apply_jq '.spec.volumes += [ { name: "nbmessages", nfs: { path: "/export/apps/jupyterhub/nbmessages", server: "its-dsmlp-fs04.ucsd.edu" } } ]'
    apply_c  "${CN}"  '.volumeMounts += [ { name: "nbmessages", mountPath: "/srv/nbmessages" } ]'
}

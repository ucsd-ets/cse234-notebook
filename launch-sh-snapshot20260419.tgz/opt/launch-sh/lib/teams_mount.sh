
#!/bin/bash


###########
# Configure static /teams PVC mount (if requested)
function setup_teams_mount() {
    apply_jq '.spec.volumes += [ { name: "teams", persistentVolumeClaim: { claimName: "teams" }} ]'
    apply_c  "${CN}"  '.volumeMounts += [ { name: "teams", mountPath: "/teams" } ]'
    apply_c  "${CN}"  '.volumeMounts += [ { name: "teams", mountPath: "'"${K8S_HOME}"'/teams" } ]'
}

awsed_get() {
    local k8s_tok=$(kubectl config view --minify=true --flatten -o jsonpath='{.users[0].user.token}')
    local path="$1"
    local curl_script
    IFS='' read -d '' -r curl_script << EOM
silent
header = "Authorization: AWSEd api_key=${k8s_tok}"
url = ${AWSED_ENDPOINT}/${path}
EOM

    local response=$(curl -s -K - <<<"${curl_script}" 2>/dev/null)
    echo "$response"
}

awsed_list_enrollments()
{
  local username=$1
  echo "$(awsed_get "enrollments?username=$username")"
}

awsed_list_groups()
{
  local username=$1
  echo "$(awsed_get "teams?username=${username}")"
}

list_groups()
{
  local username=$1
  #echo username=$username >&2
  #K8S_TOK=$(kubectl config view --raw --minify=true -o jsonpath='{.users[0].user.token}')

  echo -n "Fetching groups... " >&2
  JSON=$(awsed_list_groups "$username")
  #echo json=$JSON >&2
  echo "Done" >&2

  NUMGROUPS=$( echo "$JSON" | jq '.teams | length' )
  echo "You are a member of $NUMGROUPS teams.  Please specify your desired team on the command line, \"-G <team id>\""
  echo "$JSON" | jq -r '.teams[] | "\(.course.courseId)\t\(.teamName)\t\(.uniqueName)\t\(.gid)"' | awk -v FS="\t" 'BEGIN{printf "%-25s %-25s %-30s %s\n","Course","Team","Team ID","GID";printf "%-25s %-25s %-30s %s\n","-----","----","-------","---"}{printf "%-25s %-25s %-30s %d%s",$1,$2,$3,$4,ORS}'
  exit 1
}

get_team_gid()
{
  local username=$1
  local unique=$2
  # echo username=$username >&2
  local json=$(awsed_list_groups "$username")
  # echo $json >&2
  local kgid=$( echo "$json" | jq -r --arg grname "${unique}" -r '.teams[] | [ select(.uniqueName == $grname) ] | .[0].gid? // empty')

  echo $kgid
}

print_teams()
{
  if [ "$K8S_PRIMARY_GROUP" == "list" ]; then
    list_groups $K8S_USERNAME
    exit 1
  fi
}

setup_opa() {
  if [ -z "$OPA_ENABLED" ]; then
    return
  fi

  local enrollments=$(awsed_list_enrollments "$K8S_USERNAME")

  if [ "$K8S_COURSE" == "" ]; then
    local count
    if jq -e . /dev/null 2>&1 <<<"$enrollments"; then
        count=0
    else
        count=$(jq '. | length' &2> /dev/null <<< $enrollments)
    fi

    if [ "$count" == "0" ]; then
        echo "$K8S_USERNAME is not enrolled in any DSMLP enabled classes"
        exit
    fi
    if [ $count -gt 1 ]; then
        echo "Please select a course with -W [$(jq -r '. | map(.course)  | join(" | ")' <<< $enrollments)]"
        exit
    fi
    K8S_COURSE=$(echo "$enrollments" | jq -r '.[0].course')
  else
    # make sure the user is enrolled in the course
    jq -e --arg course "$K8S_COURSE" '.[] | select(.course == $course)' <<<$enrollments > /dev/null
    if [ $? -gt 0 ] ; then
        echo "Please select a course with -W [$(jq -r '. | map(.course)  | join(" | ")' <<< $enrollments)]"
        exit
    fi
  fi

  # set opa labels
  apply_jq --arg user   "$K8S_USERNAME"      '.metadata.labels += { "dsmlp/user": ($user) }'
  apply_jq --arg course "$K8S_COURSE"        '.metadata.labels += { "dsmlp/course": ($course) }'

  if [ "${K8S_PRIMARY_GROUP}" != "" ]; then
    # echo username=$K8S_USERNAME >&2
    kgid=$(get_team_gid "$K8S_USERNAME" "$K8S_PRIMARY_GROUP")
    # echo kgid=$kgid >&3
    apply_jq --arg gid  "$kgid" '.metadata.labels += { "dsmlp/team": ($gid) }'
  fi

  # delete opa managed volumes
  apply_jq 'del(.spec.volumes[] | select(.name == "nbmessages"))'
  apply_jq 'del(.spec.containers[0].volumeMounts[] | select(.name == "dsmlp-datasets"))'
  apply_jq 'del(.spec.volumes[] | select(.name == "dsmlp-datasets"))'

  apply_jq 'del(.spec.containers[0].volumeMounts[] | select(.name == "home"))'
  apply_jq 'del(.spec.volumes[] | select(.name == "home"))'

  apply_jq 'del(.spec.containers[0].volumeMounts[] | select(.name == "support"))'
  apply_jq 'del(.spec.volumes[] | select(.name == "support"))'
  apply_jq 'del(.spec.initContainers[0].volumeMounts[] | select(.name == "support"))'

  apply_jq 'del(.spec.containers[0].volumeMounts[] | select(.name == "nbmessages"))'
  apply_jq 'del(.spec.volumes[] | select(.name == "nbmessages"))'

  apply_jq 'del(.spec.containers[0].volumeMounts[] | select(.name == "dshm"))'
  apply_jq 'del(.spec.volumes[] | select(.name == "dshm"))'

  apply_jq 'del(.spec.initContainers)'
}

#!/bin/bash

function start_pod_sshd() {

    # This could be moved into a script residing under /opt/k8s-support
    KUBESH_NO_TTY=yes ${BINDIR}/kubesh ${K8S_POD_NAME} bash <<"EOM"
[ -f .ssh/sshd_config ] || cat > .ssh/sshd_config <<SSH_CFG
ListenAddress 127.0.0.1
Port 2222
HostKey ${HOME}/.ssh/ssh_host_rsa_key
HostKey ${HOME}/.ssh/ssh_host_dsa_key
AuthorizedKeysFile  ${HOME}/.ssh/authorized_keys
ChallengeResponseAuthentication no
Subsystem   sftp    /usr/lib/ssh/sftp-server
PidFile ${HOME}/.ssh/sshd.pid
UsePAM no
SetEnv NSS_WRAPPER_GROUP=/tmp/group.wrap NSS_WRAPPER_PASSWD=/tmp/passwd.wrap LD_PRELOAD=/opt/k8s-support/lib/libnss_wrapper.so IMPORT_TINI_ENV=yes
SSH_CFG

test -d ~/.ssh || mkdir -m 0700 ~/.ssh
test -f .ssh/ssh_host_rsa_key || ssh-keygen -f .ssh/ssh_host_rsa_key -N '' -t rsa
test -f .ssh/ssh_host_dsa_key || ssh-keygen -f .ssh/ssh_host_dsa_key -N '' -t dsa
test -f ~/private/.ssh/authorized_keys && cp -pu ~/private/.ssh/authorized_keys ~/.ssh/authorized_keys

if ! test -f .bash_profile || ! grep -q IMPORT_TINI_ENV .bash_profile; then
    # warning - quotas on the here-document delimeter are important
    cat >> .bash_profile <<"IMPORT_STANZA"

    # If running within a container via in-container SSHD, pull our full environment (PATH,LD_LIBRARY_PATH) from PID 1 which
    # we assume was set up properly by launch.sh.  
    if [ "${IMPORT_TINI_ENV}" = "yes" ]; then
        while IFS= read -rd '' var; do export "$var"; done </proc/1/environ
    fi
IMPORT_STANZA

fi

NSSWRAP=${LD_PRELOAD}
for x in /opt/k8s-support/lib/libnss_wrapper.so.0.3.1 /datasets/lib/k8s-support-interim/libnss_wrapper.so.0.3.1; do
    [ -f $x ] && NSSWRAP=${x} && break
done

LD_PRELOAD=${NSSWRAP} /usr/sbin/sshd -f .ssh/sshd_config
EOM
}

function connect_pod_sshd() {
    KUBESH_NO_TTY=yes ${BINDIR}/kubesh ${K8S_POD_NAME} bash -c 'nc localhost 2222'
}

function postlaunch_invoke_sshd() {
    start_pod_sshd

    [ "${BACKGROUND_JOB}" = "YES" ] || connect_pod_sshd
}

################
function setup_sshd() {

    # If named pod is already running, assume we're reconnecting
    local S=`pod_status`
    if [ "$S" = "Running" ]; then
        clear_traps
        [ "${BACKGROUND_JOB}" = "YES" ] || connect_pod_sshd

        exit 0
    fi

    FINAL_LAUNCH_HOOKS+=("postlaunch_invoke_sshd")
}

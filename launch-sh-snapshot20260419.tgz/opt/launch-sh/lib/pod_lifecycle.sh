#!/bin/bash


function launch_podspec() {
    if !  kubectl create -f - <<<"$JSON" >&3; then
        log_msg ERROR "Error launching pod; please check configuration, or contact ITS/ETS for assistance." 
        exit 1
    fi
}

function handle_pod_launch_status() {
    local msg

    if [[ "$1" =~ '0/'[0-9]+' nodes are available'.*nvidia.com/gpu ]]; then
        msg=$(cat <<"EOM"

*** Waiting for GPUs to become available ***

   Your job has been queued, and will be launched as soon as resources become available.   
   Please do not cancel/"Ctrl-C" as you will lose your place in line.

   To view cluster status, including GPUs in use, please visit:  https://datahub.ucsd.edu/hub/status

   or read help/FAQ:  https://support.ucsd.edu/services?id=kb_article_view&sysparm_article=KB0030470

   (Sleeping 30 seconds)

EOM
        )

        log_msg INFO "$msg"
        LAUNCH_STATUS_SECONDS=30
    fi
}

LAUNCH_STATUS_SECONDS=2

# FIXME should timeout (use bash SECONDS variable)
function monitor_launch() {
    local S NODE C 

    while true; do
        S=$(pod_status)
        C=`pod_conditions`

        if [ "$S" = "Running" ]; then
            NODE=$(pod_nodename)
            log_msg INFO "pod assigned to node: %s" "$NODE"
            log_msg INFO "${K8S_DOCKER_IMAGE} is now active."

            break
        elif [ "$S" = "Pending" -a "$SUCCESS_AT_PENDING" = "YES" ]; then
            log_msg INFO "job was successfully submitted"
            break
        elif [ "$S" = "Failed" -o "$S" = "" ]; then
            log_msg ERROR "Pod launch: %s; %s" "$S" "$C"
            log_msg ERROR "%s" "$(kubectl describe pod ${K8S_POD_NAME})"
            log_msg ERROR "%s" "$(kubectl logs ${K8S_POD_NAME})"
            log_msg ERROR "pod startup failed - contact ITS/ETS for support"
            exit 1
        elif [ "$S" = "Succeeded" ]; then
            log_msg INFO "Success - ${K8S_DOCKER_IMAGE} completed immediately."

            break
        else
            log_msg INFO "starting up - pod status: $S ; $C" 
            handle_pod_launch_status "$C"

            sleep ${LAUNCH_STATUS_SECONDS}
            continue
        fi
    done
}

function pod_conditions() {
  kubectl get events --field-selector involvedObject.name=${K8S_POD_NAME} -o jsonpath='{.items[-1].message}'
}

function pod_status() {
    kubectl get pod ${K8S_POD_NAME} -o jsonpath="{ .status.phase }" 2>/dev/null
}

function pod_term_reason {
    kubectl get pod ${K8S_POD_NAME} -o jsonpath="{ .status.reason}"
}

function pod_container_term_reason {
    kubectl get pod ${K8S_POD_NAME} -o jsonpath="{ .status.containerStatuses[0].state.terminated.reason}"
}

function pod_nodename() {
    kubectl get pod ${K8S_POD_NAME} --template='{{.spec.nodeName}}'
}

function run_prelaunch_hooks() {
    # Call our prelaunch hooks
    for x in "${PRE_LAUNCH_HOOKS[@]}"; do
        $x
    done
}

function run_launch_hooks() {
    # Call our launch hooks
    for x in "${FIRST_LAUNCH_HOOKS[@]}" "${LAUNCH_HOOKS[@]}"; do
        $x
    done

    if (( ${#FINAL_LAUNCH_HOOKS[@]} > 1 )); then
        log_msg DEBUG "Warning: multiple FINAL_LAUNCH_HOOKS specified:" "${FINAL_LAUNCH_HOOKS[@]}"
        log_msg DEBUG "They will be processed sequentially in the order listed"
    fi

    for x in "${FINAL_LAUNCH_HOOKS[@]}"; do
        $x
    done
}

# Now repeatedly monitor pod & helper status
function run_monitor_hooks() {
    # ("break 2" breaks outer loop)
    # FIXME: loop frequency should be tunable
    while sleep 3; do
        # Permit monitor hooks to remove themselves from operation, which may leave us
        # with no hook willing to call the party off.  So if array is empty, consider monitoring done.
        (( ${#MONITOR_HOOKS[@]} ))  || break
        for x in "${MONITOR_HOOKS[@]}"; do
            $x || break 2
        done
    done
}

# FIXME - should timeout if presented with unkillable pod!
function kill_pod() {
    local C=0
    kubectl delete pod --wait=false ${K8S_POD_NAME} 1>&3
    while sleep 2; do
        S=`pod_status`
        if [ "$S" != 'Running' ]; then
            break
        fi
        if (( $C > 3 )); then
            break
        fi
        log_msg INFO "Waiting for your processes to terminate..."
        C=$(( $C + 1 ))
    done
}

function cleanup_pod() {
    reason=$( (pod_container_term_reason ; pod_term_reason) | grep . )
    if [ "$reason" != "" -a "$reason" != "Completed" ]; then
        log_msg WARNING "Pod exited due to: %s" "$reason"
    fi

    [ -z "$PRESERVE_POD" ] && kill_pod
}

function run_cleanup_hooks() {
    # Call our cleanup hooks
    for x in "${CLEANUP_HOOKS[@]}"; do
        $x
    done
}



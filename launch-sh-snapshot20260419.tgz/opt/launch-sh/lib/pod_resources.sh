#!/bin/bash

################
# Setup for GPU number/type (including CPU-only affinities)
function setup_gpu() {
    if (( $K8S_NUM_GPU == 0 )); then
        return 1
        apply_jq_stdin <<"EOM"
            .spec.affinity?.nodeAffinity?.preferredDuringSchedulingIgnoredDuringExecution += [ 
                { 
                    preference: { 
                        matchExpressions: [
                            {
                                key: "admitcpupods",
                                operator: "In",
                                values: [ "true"]
                            }
                        ]
                    },
                    weight: 10
            }
        ]
EOM
    else
        set_c_resources "${CN}"  "requests" "nvidia.com/gpu"    "$K8S_NUM_GPU"
        set_c_resources "${CN}"  "limits"   "nvidia.com/gpu"    "$K8S_NUM_GPU"
            
        #prepend_c_path "${CN}" "LD_LIBRARY_PATH" "/usr/local/nvidia/lib:/usr/local/nvidia/lib64:/opt/conda/pkgs/cudatoolkit-11.2.2-he111cf0_8/lib:/opt/conda/pkgs/cudnn-8.2.1.32-h86fa8c9_0/lib"

        if [ "$K8S_GPU_MODEL_NAME" ]; then
            apply_jq '.spec.nodeSelector += { "gputype": $gpu }' \
                --arg gpu "${K8S_GPU_MODEL_NAME}"
        fi

    fi

}

function setup_mem_limits() {
    local halfram=$(( $K8S_GB_MEM / ${K8S_LIMIT_DIVISOR:-2} ))

    set_c_resources "${CN}"  "requests"   "memory"    "${halfram}Gi"
    set_c_resources "${CN}"  "limits"   "memory"    "${K8S_GB_MEM}Gi"
}

function setup_cpu_limits() {
    local halfcpu=$(( $K8S_NUM_CPU / ${K8S_LIMIT_DIVISOR:-2} ))

    set_c_resources "${CN}"  "requests"   "cpu"    "${halfcpu}"
    set_c_resources "${CN}"  "limits"   "cpu"    "${K8S_NUM_CPU}"
}

awsed_get()
{
  url="$1"
  #echo AWSED_RESPONSE=$( jq <<< $AWSED_RESPONSE ) >&3
  response=$( jq -r ".[] | select(.url==\"$url\") | .response.body" <<< "$AWSED_RESPONSE")
  local status=$( jq -r ".[] | select(.url==\"$url\") | .response.status" <<< "$AWSED_RESPONSE")
  #echo "url=$url, response=$response" >&3
  echo "$response"
  if [ "$status" == "null" ]; then
    status=200
  fi
  return $status
}

function launch_podspec() {
  echo "$JSON" > "$CAPTURED_JSON"
}

function monitor_launch() {
  :
}

function run_monitor_hooks() {
  :
}

#function run_launch_hooks() {
#  :
#}

function run_cleanup_hooks() {
  :
}

function prelaunch_display_podname() {
  :
}

function launch_interactive_shell() {
  :
}

function launch_follow_logs() {
  :
}

function launch_background_job() {
  :
}

function postlaunch_invoke_sshd() {
  :
}

function hook_jupyter_displayurl() {
  :
}


# Support subpath mounts 
# (simliar to NFS:   /mountpoint:volume:subpath/
function setup_subpath_mount() {
    local mntlist mntinfo a d
    IFS=, read -a mntlist <<<"$K8S_SUBPATH_MOUNT"

    for a in "${mntlist[@]}"; do
        # Omit blank entries to permit blind appending of additional entries # #K8S_SUBPATH_MOUNT"="${K8S_SUBPATH_MOUNT"};${new-mntblock}"
        [[ "$a" == "" ]] && continue

        IFS=: read -a mntinfo <<<"$a"

        if (( ${#mntinfo[@]} != 3 )) || [[ ! ${mntinfo[0]} =~ ^/ ]] || [[ ! ${mntinfo[1]} =~ ^[-0-9a-z.]+$ ]] || [[ ${mntinfo[2]} =~ ^/ ]]; then
            echo "$0: malformed K8S_SUBPATH_MOUNT; expected: /mountpoint:volume:subpath/[,/mountpoint2:volume2:subpath2/,..." 1>&2
            exit 1
        fi

        apply_c "${CN}" '.volumeMounts += [ { mountPath: "'"${mntinfo[0]}"'", name: "'"${mntinfo[1]}"'", subPath: "'"${mntinfo[2]}"'" } ]'
    done
}

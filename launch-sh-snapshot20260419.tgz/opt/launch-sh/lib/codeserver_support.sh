#!/bin/bash

# Modeled after our Jupyter notebook support

function hook_codeserver_displayurl() {
    echo "You may access your Code-Server (VS Code) at: ${CS_URL} using password ${CS_TOKEN}"
}

################
# Set up Code-Server (oss in-browser VSCode)
CODE_SERVER_PORT=8889
function setup_codeserver() {

    local tmp_tok=($(dd if=/dev/urandom bs=512 count=1 status=none | sha256sum))
    CS_TOKEN=${tmp_tok[0]}

    local cs_base=/codeserver/${K8S_USERNAME}/

    if [ "$LEGACY_PROXY" = "YES" ]; then
        cs_port=${SOCAT_PORT_MAP[${CODE_SERVER_PORT}]:-}
        if [ \! "$cs_port" ]; then
            echo "Error: could not allocate Legacy codeserver proxy port; contact ITS/ETS" 1>&2
            exit 1
        fi

        CS_URL="http://${PROXY_HOSTNAME}:${cs_port}"
    else
        CS_URL="https://datahub-x.ucsd.edu${cs_base}"
    fi

    set_c_env       "${CN}"   "PASSWORD"              "${CS_TOKEN}"
    set_c_env       "${CN}"   "CODE_SERVER_PORT"      "$CODE_SERVER_PORT"
    set_c_env       "${CN}"   "CODE_SERVER_URL"           "${CS_URL}"

    # Post-legacy proxy (e.g. service/ingress) will rely on this app label
    apply_jq        '.metadata?.labels? += { app: "codeserver" }'

    # Push hook call to display the URL
    LAUNCH_HOOKS+=( hook_codeserver_displayurl )
}


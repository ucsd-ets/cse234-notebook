
################
# Set up Batch
function setup_batch() {
    if [ "$CN_CMD_MODIFIED" != "NO" ]; then
        echo "$0: only one container command modification permitted; cur=batch; previous=$CN_CMD_MODIFIED"; exit 1;
    fi
    CN_CMD_MODIFIED="batch"

    # "--args --" ensures the jq arg parser doesn't interpret the batch args
    # see https://github.com/stedolan/jq/pull/1989 re: documenting this behavior
    apply_c "${CN}" '.command = [ .command[], $ARGS.positional[] ]' --args -- "${BATCH_CMDLINE[@]}"

}

function prelaunch_display_podname() {
    echo $(date) "Submitting job ${K8S_POD_NAME}" 1>&3
}

function launch_dump_podspec() {
    echo "$JSON"
}

function setup_interactive_shell() {
    FINAL_LAUNCH_HOOKS+=("launch_interactive_shell")
}

function launch_interactive_shell() {
    ${BINDIR}/kubesh "${K8S_POD_NAME}" bash -l
}

function setup_follow_logs() {
    FINAL_LAUNCH_HOOKS+=("launch_follow_logs")
}

function launch_follow_logs() {
    kubectl logs -f ${K8S_POD_NAME}
}

function setup_background_job() {
    FINAL_LAUNCH_HOOKS+=("launch_background_job")
}

function launch_background_job() {
        echo "Connect to your background pod via: \"kubesh ${K8S_POD_NAME}\"" >&3
        echo "Please remember to shut down via: \"kubectl delete pod ${K8S_POD_NAME}\" ; \"kubectl get pods\" to list running pods." >&3
        echo "You may retrieve output from your pod via: \"kubectl logs ${K8S_POD_NAME}\"." >&3
        echo "PODNAME=${K8S_POD_NAME}"

        clear_traps

        exit 0
}

################
# Set up container command "pause" - used only if no other command was provided
function setup_fallback_pause() {
    if [ "$PERMIT_FALLBACK_PAUSE" != "YES" ]; then
        echo "$0: must specify command to be executed within container" 1>&2; exit 1
    fi
    if [ "$CN_CMD_MODIFIED" != "NO" ]; then
        echo "$0: only one container command modification permitted; cur=fallback_pause; previous=$CN_CMD_MODIFIED"; exit 1;
    fi
    CN_CMD_MODIFIED="fallback_pause"

    apply_c "${CN}" '.command = [ .command[], $ARGS.positional[] ]' --args "/opt/k8s-support/bin/pause"
}
